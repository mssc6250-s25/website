# Load required libraries
library(tidyverse)
library(glmnet)
library(caret)
library(reshape2)  # For correlation heatmap

# Load data
data <- read.csv("/Users/jiaqiwang/Desktop/train.csv")

if(any(sapply(data, is.character))) {
  data <- data %>% mutate(across(where(is.character), as.factor))
}

train_data_numeric <- data %>%
  mutate(across(where(is.factor), as.numeric))

# Handle missing values (impute with median)
train_data <- train_data_numeric %>% mutate(across(everything(), ~ifelse(is.na(.), median(., na.rm = TRUE), .)))

# Select top 20 predictors using correlation with SalePrice
correlations <- cor(train_data, use = "pairwise.complete.obs")
top_features <- names(sort(abs(correlations["SalePrice", -which(names(train_data) == "SalePrice")]), decreasing = TRUE))[1:20]
top_features

# Define predictor matrix and response vector
X <- as.matrix(train_data[, top_features])
y <- train_data$SalePrice

# Split data into training and test sets
set.seed(123)
train_indices <- sample(1:nrow(train_data), size = 0.8 * nrow(train_data))
X_train <- X[train_indices, ]
y_train <- y[train_indices]
X_test <- X[-train_indices, ]
y_test <- y[-train_indices]

# Standardize data
#preProc <- preProcess(X_train, method = c("center", "scale"))
#X_train <- predict(preProc, X_train)
#X_test <- predict(preProc, X_test)

# Ridge Regression
ridge_model <- cv.glmnet(X_train, y_train, alpha = 0)  # alpha = 0 for ridge
ridge_pred <- predict(ridge_model, s = ridge_model$lambda.min, newx = X_test)
ridge_rmse <- sqrt(mean((ridge_pred - y_test)^2))
ridge_mae <- mean(abs(ridge_pred - y_test))

# Lasso Regression
lasso_model <- cv.glmnet(X_train, y_train, alpha = 1)  # alpha = 1 for lasso
lasso_pred <- predict(lasso_model, s = lasso_model$lambda.min, newx = X_test)
lasso_rmse <- sqrt(mean((lasso_pred - y_test)^2))
lasso_mae <- mean(abs(lasso_pred - y_test))

# Print results
print(paste("Ridge RMSE:", round(ridge_rmse, 2)))
print(paste("Lasso RMSE:", round(lasso_rmse, 2)))
print(paste("Ridge MAE:", round(ridge_mae, 2)))
print(paste("Lasso MAE:", round(lasso_mae, 2)))

# Extract non-zero coefficients from Lasso model
lasso_coeffs <- coef(lasso_model, s = "lambda.min")
lasso_coeffs <- as.data.frame(as.matrix(lasso_coeffs))
lasso_coeffs$Feature <- rownames(lasso_coeffs)
colnames(lasso_coeffs)[1] <- "Coefficient"
lasso_coeffs <- lasso_coeffs %>% arrange(desc(abs(Coefficient)))

print("Selected Features in Lasso Model:")
print(lasso_coeffs)

# ------------------- Visualization -------------------

# 1. Correlation Heatmap
cor_melt <- melt(correlations[top_features, c(top_features, "SalePrice")])
ggplot(cor_melt, aes(Var1, Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", midpoint = 0, limit = c(-1, 1)) +
  theme_minimal() +
  labs(title = "Correlation Heatmap of Top 20 Features", x = "Features", y = "Features") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# 2. Feature Importance from Lasso
ggplot(lasso_coeffs, aes(x = reorder(Feature, abs(Coefficient)), y = Coefficient)) +
  geom_col(fill = "steelblue") +
  coord_flip() +
  theme_minimal() +
  labs(title = "Feature Importance from Lasso Regression", x = "Feature", y = "Coefficient")

# 3. Actual vs Predicted SalePrice (Ridge and Lasso)
ridge_results <- data.frame(Actual = y_test, Predicted = as.vector(ridge_pred), Model = "Ridge")
lasso_results <- data.frame(Actual = y_test, Predicted = as.vector(lasso_pred), Model = "Lasso")
results <- rbind(ridge_results, lasso_results)

ggplot(results, aes(x = Actual, y = Predicted, color = Model)) +
  geom_point(alpha = 0.6) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
  theme_minimal() +
  labs(title = "Actual vs Predicted Sale Prices", x = "Actual Sale Price", y = "Predicted Sale Price")

# 4. Residual Plot for Lasso
lasso_residuals <- data.frame(Actual = y_test, Residuals = as.vector(lasso_pred - y_test))

ggplot(lasso_residuals, aes(x = Actual, y = Residuals)) +
  geom_point(alpha = 0.5, color = "red") +
  geom_hline(yintercept = 0, linetype = "dashed") +
  theme_minimal() +
  labs(title = "Residual Plot (Lasso)", x = "Actual Sale Price", y = "Residuals")

