library(tidyverse)
library(glmnet)
library(caret)

# Load data
data <- read.csv("/Users/jiaqiwang/Desktop/train.csv")

if(any(sapply(data, is.character))) {
  data <- data %>% mutate(across(where(is.character), as.factor))
}

train_data_numeric <- data %>%
  mutate(across(where(is.factor), as.numeric))

# Handle missing values (impute with median)
train_data <- train_data_numeric %>% mutate(across(everything(), ~ifelse(is.na(.), median(., na.rm = TRUE), .)))

# Separate predictors and response
X <- train_data %>% select(-SalePrice)
y <- train_data$SalePrice

# Standardize data for PCA
preProc <- preProcess(X, method = c("center", "scale"))
X_scaled <- predict(preProc, X)

# Perform PCA
pca_result <- prcomp(X_scaled, center = TRUE, scale. = TRUE)
pca_importance <- apply(abs(pca_result$rotation), 1, sum)
top20 <- names(sort(pca_importance, decreasing = TRUE))[1:20]
top20

# Use all principal components
X_pca <- pca_result$x

# Split data into training and test sets
set.seed(123)
trainIndex <- sample(1:nrow(train_data), size = 0.8 * nrow(train_data))
X_train <- X_pca[trainIndex, ]
y_train <- y[trainIndex]
X_test <- X_pca[-trainIndex, ]
y_test <- y[-trainIndex]

# Ridge Regression
ridge_model <- cv.glmnet(X_train, y_train, alpha = 0)  # alpha = 0 for ridge
ridge_pred <- as.vector(predict(ridge_model, s = ridge_model$lambda.min, newx = X_test))
ridge_rmse <- sqrt(mean((ridge_pred - y_test)^2))
ridge_mae <- mean(abs(ridge_pred - y_test))
ridge_model$lambda.min

# Lasso Regression
lasso_model <- cv.glmnet(X_train, y_train, alpha = 1)  # alpha = 1 for lasso
lasso_pred <- as.vector(predict(lasso_model, s = lasso_model$lambda.min, newx = X_test))
lasso_rmse <- sqrt(mean((lasso_pred - y_test)^2))
lasso_mae <- mean(abs(lasso_pred - y_test))
lasso_model$lambda.min
# Print results
print(paste("Ridge RMSE:", round(ridge_rmse, 2)))
print(paste("Lasso RMSE:", round(lasso_rmse, 2)))
print(paste("Ridge MAE:", round(ridge_mae, 2)))
print(paste("Lasso MAE:", round(lasso_mae, 2)))


# Visualization with ggplot2
# Scree Plot
explained_variance <- pca_result$sdev^2 / sum(pca_result$sdev^2)
scree_data <- data.frame(PC = 1:length(explained_variance), Variance = explained_variance)

ggplot(scree_data, aes(x = PC, y = Variance)) +
  geom_bar(stat = "identity", fill = "gray") +
  labs(title = "Scree Plot of PCA", x = "Principal Component", y = "Variance Explained") +
  theme_minimal()

# Actual vs Predicted Plot (Ridge)
ridge_results <- data.frame(Actual = y_test, Predicted = ridge_pred)

ggplot(ridge_results, aes(x = Actual, y = Predicted)) +
  geom_point(color = "blue", alpha = 0.5) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
  labs(title = "Actual vs Predicted (Ridge)", x = "Actual SalePrice", y = "Predicted SalePrice") +
  theme_minimal()

# Actual vs Predicted Plot (Lasso)
lasso_results <- data.frame(Actual = y_test, Predicted = lasso_pred)

ggplot(lasso_results, aes(x = Actual, y = Predicted)) +
  geom_point(color = "red", alpha = 0.5) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed") +
  labs(title = "Actual vs Predicted (Lasso)", x = "Actual SalePrice", y = "Predicted SalePrice") +
  theme_minimal()

# Residual Plot
ridge_residuals <- data.frame(Residuals = ridge_pred - y_test)
ggplot(ridge_residuals, aes(x = Residuals)) +
  geom_histogram(binwidth = 5000, fill = "blue", alpha = 0.6) +
  labs(title = "Residuals of Ridge Regression", x = "Residuals", y = "Count") +
  theme_minimal()
