library(tidyverse)
library(glmnet)
library(caret)

# Load filtered datasets
train_data <- read.csv("/Users/jiaqiwang/Desktop/filtered_train_data.csv")
test_data <- read.csv("/Users/jiaqiwang/Desktop/filtered_test_data.csv")

# Handle missing values (impute with median)
train_data <- train_data %>% mutate(across(everything(), ~ifelse(is.na(.), median(., na.rm = TRUE), .)))
test_data <- test_data %>% mutate(across(everything(), ~ifelse(is.na(.), median(., na.rm = TRUE), .)))

# Convert categorical variables to numeric if present
if(any(sapply(train_data, is.character))) {
  train_data <- train_data %>% mutate(across(where(is.character), as.factor))
}
if(any(sapply(test_data, is.character))) {
  test_data <- test_data %>% mutate(across(where(is.character), as.factor))
}

if(any(sapply(train_data, is.factor))) {
  train_data <- train_data %>% mutate(across(where(is.factor), as.numeric))
}
if(any(sapply(test_data, is.factor))) {
  test_data <- test_data %>% mutate(across(where(is.factor), as.numeric))
}

# Define predictor matrix and response vector
X_train <- subset(train_data, select = -SalePrice)
y_train <- train_data$SalePrice
X_test <- test_data

test_data$SalePrice <- NA  # Placeholder since SalePrice is unknown in test set

# Standardize data
preProc <- preProcess(X_train, method = c("center", "scale"))
X_train <- predict(preProc, X_train)
X_test <- predict(preProc, X_test)

# Ridge Regression
ridge_model <- cv.glmnet(X_train, y_train, alpha = 0)  # alpha = 0 for ridge
ridge_pred <- predict(ridge_model, s = ridge_model$lambda.min, newx = X_test)

# Lasso Regression
lasso_model <- cv.glmnet(X_train, y_train, alpha = 1)  # alpha = 1 for lasso
lasso_pred <- predict(lasso_model, s = lasso_model$lambda.min, newx = X_test)

# Print results
ridge_rmse <- sqrt(mean((ridge_pred - y_train)^2))
lasso_rmse <- sqrt(mean((lasso_pred - y_train)^2))

print(paste("Ridge RMSE:", round(ridge_rmse, 2)))
print(paste("Lasso RMSE:", round(lasso_rmse, 2)))

# Extract non-zero coefficients from Lasso model
lasso_coeffs <- coef(lasso_model, s = "lambda.min")
print("Selected Features in Lasso Model:")
print(lasso_coeffs[lasso_coeffs != 0])
